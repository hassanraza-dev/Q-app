import * as firebase from 'firebase'

  // Your web app's Firebase configuration
  const firebaseConfig = {
    apiKey: "AIzaSyCcI1FpIm3AgQhGrOkFbV3jIllmhuszqxQ",
    authDomain: "q-app-79e78.firebaseapp.com",
    databaseURL: "https://q-app-79e78.firebaseio.com",
    projectId: "q-app-79e78",
    storageBucket: "q-app-79e78.appspot.com",
    messagingSenderId: "212993066569",
    appId: "1:212993066569:web:c35c698a5657d158e06198",
    measurementId: "G-BQLK31VPVE"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();

  const auth = firebase.auth();

  function registerUser(email,password){

   return auth.createUserWithEmailAndPassword(email,password)
    
  }

  function loginUser(email,password){

   return auth.signInWithEmailAndPassword(email,password)
    
  }

     function fbLogin()
     {
      var provider = new firebase.auth.FacebookAuthProvider();

      firebase.auth().signInWithPopup(provider).then(function(result) {
       // This gives you a Facebook Access Token. You can use it to access the Facebook API.
       var token = result.credential.accessToken;
       // The signed-in user info.
       var user = result.user;
       console.log('user***',user)
       
       // ...
     }).catch(function(error) {
       // Handle Errors here.
       var errorCode = error.code;
       var errorMessage = error.message;
       // The email of the user's account used.
       var email = error.email;
       // The firebase.auth.AuthCredential type that was used.
       var credential = error.credential;
       // ...
     });
     }
  export{
      registerUser,
      loginUser,
      fbLogin,
      firebase

  }
import React , {useState}from 'react'
import './index.css'
// import  'bootstrap/dist/css/bootstrap.min.css'   
import { Modal , Button} from 'react-bootstrap'


const Company = function()


{
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
  
    return (
      <>
      <div >
        <div className='container' onClick={handleShow}>
          <h1>+</h1>
        </div>
  </div>
        <Modal show={show} onHide={handleClose} style={{opacity:'1'}}>
          <Modal.Header closeButton>
            <Modal.Title>Add Company</Modal.Title>
          </Modal.Header>
          <Modal.Body>
          <div className="modal-body">
          <div className="md-form mb-5">
            <input type="email" id="Form-email5" className="form-control validate white-text"/>
            <label data-error="wrong" data-success="right" for="Form-email5">Your email</label>
          </div>

          <div className="md-form pb-3">
            <input type="password" id="Form-pass5" className="form-control validate white-text"/>
            <label data-error="wrong" data-success="right" for="Form-pass5">Your password</label>
            
          </div>
          </div>

          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button variant="primary" onClick={handleClose}>
              Add
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }
  
  


  


export default Company;
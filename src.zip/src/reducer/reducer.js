
const estate = 
{
    name:'hassan',
    age:['12','44','34']
}

const reducer = (state=estate,action)=>
{
        return state;
}

export default reducer;